package University;
/**
 * @author Christina Deligiorgi
 *This documents Student Types
 */

public enum StudentType {

	//Types that can be used
	
	UGStudent,
	PGTStudent,
	PGRStudent

}
