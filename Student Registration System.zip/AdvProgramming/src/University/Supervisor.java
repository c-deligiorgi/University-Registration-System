package University;
/**
 * @author Christina Deligiorgi
 *
 */

public class Supervisor {
	private String name;
	
	public Supervisor(String name) {	
		this.name = name;
	}
	
	public String getName() {
		return name;
	}	

}